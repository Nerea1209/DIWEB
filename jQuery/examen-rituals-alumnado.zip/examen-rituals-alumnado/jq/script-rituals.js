$(document).ready(function () {
    // MENÚ PRINCIPAL
    // a
    $("nav#menu-principal>label").on("click", function () {
        // Controlamos la acumulación de efectos
        $(this).next().stop(false, true)
        $(this).children().stop(false, true)
        $("nav#menu-principal>ul#menu-toggle>li>ul").stop(false, true)
        $("nav#menu-principal>ul#menu-toggle>li>a>.angulo").stop(false, true)
        $("nav#menu-principal>ul#menu-toggle>li>a").stop(false, true)

        // Mostramos el menú
        if ($(this).next().css("display") == "none") {
            $(this).next().slideDown("fast")
            //b
            $(this).children().animate({
                "color": "#e9a140"
            })
        } else {
            // f
            $(this).next().slideUp("fast")
            $(this).children().animate({
                "color": "white"
            })
            $("nav#menu-principal>ul#menu-toggle>li>ul").slideUp("fast")
            $("nav#menu-principal>ul#menu-toggle>li>a>.angulo").rotate({ animateTo: 0 })
            $("nav#menu-principal>ul#menu-toggle>li>a").animate({
                "color": "white"
            })
        }
    })

    // c
    $("nav#menu-principal>ul#menu-toggle>li>a").css("color", "white")
    $("nav#menu-principal>ul#menu-toggle>li>a").on("click", function () {
        $("nav#menu-principal>ul#menu-toggle>li>ul").stop(false, true)
        $(this).stop(false, true)
        $("nav#menu-principal>ul#menu-toggle>li>a>.angulo").stop(false, true)
        if ($(this).next().css("display") == "none") {
            $("nav#menu-principal>ul#menu-toggle>li>a").animate({
                "color": "white"
            })
            $("nav#menu-principal>ul#menu-toggle>li>ul").slideUp("fast")
            $("nav#menu-principal>ul#menu-toggle>li>a>.angulo").rotate({ animateTo: 0 })
            $(this).next().slideDown("fast")
            //d
            $(this).animate({
                "color": "#e9a140"
            })
            // e
            $(this).children(".angulo").rotate({ animateTo: -90 })
        } else {
            $(this).next().slideUp("fast")
            //d
            $(this).animate({
                "color": "white"
            })
            // e
            $(this).children(".angulo").rotate({ animateTo: 0 })
        }
    })

    // g
    $(document).on("scroll", function () {
        // Controlamos la acumulación de efectos
        $("nav#menu-principal>ul").stop(false, true)
        $("nav#menu-principal>label>span").stop(false, true)
        $("nav#menu-principal>ul#menu-toggle>li>ul").stop(false, true)
        $("nav#menu-principal>ul#menu-toggle>li>a>.angulo").stop(false, true)
        $("nav#menu-principal>ul#menu-toggle>li>a").stop(false, true)

        // Volvemos al estado inicial de menú
        $("nav#menu-principal>ul").slideUp("fast")
        $("nav#menu-principal>label>span").animate({
            "color": "white"
        })
        $("nav#menu-principal>ul#menu-toggle>li>ul").slideUp("fast")
        $("nav#menu-principal>ul#menu-toggle>li>a>.angulo").rotate({ animateTo: 0 })
        $("nav#menu-principal>ul#menu-toggle>li>a").animate({
            "color": "white"
        })
    })

    // h
    $(window).on("resize", function () {
        $("nav#menu-principal>ul").removeAttr("style")
        $("nav#menu-principal>label>span").removeAttr("style")
        $("nav#menu-principal>ul#menu-toggle>li>ul").removeAttr("style")
        $("nav#menu-principal>ul#menu-toggle>li>a>.angulo").removeAttr("style")
        $("nav#menu-principal>ul#menu-toggle>li>a").css("color", "white")
    })

    // ICONO Y BOTÓN DE COMPRA
    //a y b
    $("section#sec-gelducha>article.item-sec>img, section#sec-gelducha>article.item-sec>input").on("click", function () {
        // Controlo acumulación de eventos
        $("section#sec-gelducha>span#cartel").stop(true)

        // Para calcular el left
        let size = $("section#sec-gelducha>span#cartel").css("width")
        let left = ($(this).offset().left - parseInt(size)) - 2
        left <= 0 ? left = 0 : left;

        // Para calcular el top
        let altura = $("section#sec-gelducha>span#cartel").css("height")
        let top = $(this).offset().top + (parseInt(altura) / 4)
        top <= 0 ? top = 0 : top;

        // Animo el cartel
        $("section#sec-gelducha>span#cartel").css({
            "top": top + "px",
            "left": left + "px"
        }).fadeIn().delay(1000).fadeOut()
    })

    // COOKIES
    // a
    $("div#cookies").css("display", "flex")
    // b
    $("div#cookies>span").on("click", function () {
        $(this).parent().fadeOut()
    })

    // FORMULARIO
    // a
    $("section#registro>div>input").on("focusout", function () {
        if ($(this).val().length == 0) {
            $(this).next().css("visibility", "visible")
        } else {
            // b
            $(this).next().css("visibility", "hidden")
        }
    })
})